﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Theatre2025;Integrated Security=True;Encrypt=False";
    }
}
